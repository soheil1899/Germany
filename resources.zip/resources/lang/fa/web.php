<?php

return [
    'home'=>'خانه',
    'product'=>'محصولات',
    'help'=>'راهنما',
    'about'=>'درباره ما',
    'contact'=>'تماس با ما ',
    'Quick links'=>'دسترسی سریع ',
    'phone'=>'تلفن ',
    'fax'=>'تلفکس ',
    'About'=>'درباره ما ',
    'email'=>'ایمیل ',
    'products'=>'محصولات',


    'blog'=>'بلاگ',
    'Contact Way'=>'راه های دسترسی ',
    'Send Request'=>'ارسال درخواست ',
    'address'=>'آدرس ',
    'See All Product'=>'نمایش محصولات ',
    'call us'=>'تماس با ما ',
    'social network'=>'شبکه های اجتماعی ',
    'contact us'=>'تماس با ما',
    'Toman'=>' تومان اعتبار دارید ',
    'Charge Credit You Need'=>'شما نیاز به: ',
    'Contact'=>'راه های ارتباطی',
    'Your Have Not Enough Credit . Please Charge Your Credit. Click On Link'=>'شما اعتبار کافی ندارید . برای شارژ اعتبار روی لینک کلیک نمایید',
    'The current mobile code is incorrect.'=>'کد تایید موبایل اشتباه می باشد',
    'Please Login User'=>'برای خرید با <a href="/login">وارد شوید</a>یا <a href="/register">ثبت نام </a> نمایید',
    'You have already bought this product. See your List in your panel'=>'شما قبلا این محصول را  تهیه کرده اید . برای دیدن وضعیت محصول <a href="/userpanel/onlineclass">اینجا</a> کلیک نمایید.',

];