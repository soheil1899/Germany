
<div class="row mx-0 text-center footerbottom py-2">
    <div class="widthfit mx-auto">
        Urheberrechte © 2019 {{$setting['websitename']}}. Design und Entwicklung von
    <a href="https://afrang.dev/">
        Afrang-Gruppe
    </a>
    </div>
</div>
