@extends('website.layouts.master')

@section('content')

    <our-product></our-product>

    <slider-component></slider-component>





    <news-component></news-component>


    <about-firstpage></about-firstpage>
    <google-map></google-map>

@endsection
