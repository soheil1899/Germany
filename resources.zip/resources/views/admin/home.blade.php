@extends('admin.dashboard')

@section('page')
<div>
<dashboard :menu="menu"></dashboard>
</div>

@endsection
