<template>
    
</template>

<script>
    export default {
        name: "animation"
    }
</script>

<style scoped>


</style>