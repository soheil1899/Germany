module.exports = {
    hello_world : 'Hellow World!',
    Language : 'Language',
}