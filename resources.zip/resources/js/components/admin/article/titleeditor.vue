<template>
    <input class="form-control"  >

</template>

<script>

    export default {
        name: "titleeditor",
        props: {
            namevalue:String
        },
        data() {

        }


    }
</script>

<style scoped>

</style>