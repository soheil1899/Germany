<template>
    <div>
        fdsfs
    </div>
</template>

<script>
    export default {
        name: "advercenter"
    }
</script>

<style scoped>

</style>