<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "Classeditonline"
    }
</script>

<style scoped>

</style>